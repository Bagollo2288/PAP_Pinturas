<?php
session_start();
if (!isset($_SESSION['id']) || $_SESSION['id'] == '') {
    header("Location: login.html"); 
    exit();
}

// Ligar à base de dados
$conn = new mysqli('localhost', 'root', '', 'pinturas');
if ($conn->connect_error) {
    die("Erro na ligação à base de dados: " . $conn->connect_error);
}

$estimativa = null;
$nomeCliente = null;

if (isset($_SESSION['ultimo_orcamento_id'])) {
    $idOrcamento = $_SESSION['ultimo_orcamento_id'];

    $stmt = $conn->prepare("SELECT nome, tipo_pintura, area, cor, distrito FROM orcamentos WHERE id = ?");
    $stmt->bind_param("i", $idOrcamento);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $dados = $result->fetch_assoc();
        $nomeCliente = htmlspecialchars($dados['nome']);
        $tipo = $dados['tipo_pintura'];
        $area = (float)$dados['area'];
        $cor = $dados['cor'];
        $distrito = $dados['distrito'];

        $tabelaPrecos = [
            'interior' => [
                '#ffffff' => 5,
                '#f5f5dc' => 5,
                'default' => 6
            ],
            'exterior' => [
                '#ffffff' => 6,
                '#f5f5dc' => 6,
                'default' => 7.2
            ],
            'ambos' => [
                '#ffffff' => 10,
                '#f5f5dc' => 10,
                'default' => 12
            ],
        ];

        $fatoresDistritos = [
            'Lisboa' => 2.0,
            'Porto' => 7.0,
            'Setúbal' => 1.0,
            'Faro' => 4.0,
            'Coimbra' => 4.5,
            'Outros' => 2.0,
        ];

        $corLower = strtolower($cor);

        if (isset($tabelaPrecos[$tipo])) {
            $precoPorMetro = $tabelaPrecos[$tipo][$corLower] ?? $tabelaPrecos[$tipo]['default'];
        } else {
            $precoPorMetro = 5;
        }

        $fatorDistrito = $fatoresDistritos[$distrito] ?? 1.0;

        $estimativaNum = $area * $precoPorMetro * $fatorDistrito;
        $estimativa = number_format($estimativaNum, 2, ',', '.');
    }

    $stmt->close();
    unset($_SESSION['ultimo_orcamento_id']);
}


$conn->close();
?>



<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles/sucesso.css" />
  <title>Sucesso</title>
</head>
<body>

<header>
  <div class="navbar">
    <div class="logo">
      <a href="<?php 
        echo (isset($_SESSION['tipo_utilizador']) && $_SESSION['tipo_utilizador'] == 1) ? 'admin_dashboard.php' : 'index.php';
      ?>">
        <img src="imagens/Logo.png" alt="Logotipo Pinturas do Sr. Graça" />
      </a>
    </div>
    <ul class="links">
      <li><a href="index.php">Início</a></li>
      <li><a href="orcamento.php">Orçamento</a></li>
      <li><a href="simulador.php">Simulador</a></li>
      <li><a href="sobre.php">Sobre Nós</a></li>
      <li><a href="contacto.php">Contacto</a></li>

      <?php if (isset($_SESSION['id'])): ?>
        <button type="button" class="botao-logout" onclick="window.location.href='logout.php'">Logout</button>
      <?php else: ?>
        <button type="button" class="botao-login" onclick="window.location.href='login.html'">Login</button>
      <?php endif; ?>
    </ul>
  </div>
</header>

<div class="i">
  <h1>Mensagem Enviada com Sucesso!</h1>
  

  <button type="button" onclick="window.location.href='index.php'">Voltar para o menu inicial</button>
</div>

</body>
</html>
