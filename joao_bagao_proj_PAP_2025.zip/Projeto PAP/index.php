    <?php
    session_start(); // Inicia a sessão
    ?>

    <!DOCTYPE html>
    <html lang="pt">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Pinturas do Sr. Graça</title>
        <link rel="stylesheet" href="styles/index.css" />
    </head>
    <body>
    <div class="overlay"></div>
        <header>
            <div class="navbar">
                <div class="logo">
    <a href="<?php 
        if (isset($_SESSION['id']) && isset($_SESSION['tipo_utilizador'])) {
            echo $_SESSION['tipo_utilizador'] == 1 ? 'admin_dashboard.php' : 'index.php';
        } else {
            echo 'index.php';
        }
    ?>">
        <img src="imagens/Logo.png" alt="Logotipo Pinturas do Sr. Graça" />
    </a>
</div>


                <ul class="links">
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="orcamento.php">Orçamento</a></li>
                    <li><a href="simulador.php">Simulador</a></li>
                    <li><a href="sobre.php">Sobre Nós</a></li>
                    <li><a href="contacto.php">Contacto</a></li>

                    <li>
<?php if (isset($_SESSION['id']) && $_SESSION['id'] != ''): ?>
    <button type="button" class="botao-logout" onclick="window.location.href='logout.php'">Logout</button>
<?php else: ?>
    <button type="button" class="botao-login" onclick="window.location.href='login.html'">Login</button>
<?php endif; ?>
</li>

                </ul>
                <button class="menu-toggle" onclick="toggleMenu()">☰</button>

        <!-- Continua dentro da navbar -->
        <div class="mobile-popup" id="mobilePopup">
            <button class="close-btn" onclick="toggleMenu()">✕</button>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="orcamento.php">Orçamento</a></li>
                <li><a href="simulador.php">Simulador</a></li>
                <li><a href="sobre.php">Sobre Nós</a></li>
                <li><a href="contacto.php">Contacto</a></li>
                <?php if (isset($_SESSION['id']) && $_SESSION['id'] != ''): ?>
                    <button class="botao-logout" onclick="window.location.href='logout.php'">Logout</button>
                <?php else: ?>
                    <button class="botao-login" onclick="window.location.href='login.html'">Login</button>
                <?php endif; ?>
            </ul>
        </div>
    </div>
        </header>

        <div class="main-content">
    <div class="container">
        <h1>
            Bem-vindo 
            <?php 
            // Verifica se o usuário está logado e tem nome na sessão
            if(isset($_SESSION['id']) && isset($_SESSION['nome_utilizador'])) {
                echo htmlspecialchars($_SESSION['nome_utilizador']) . ', às Pinturas do Sr. Graça';
            } else {
                echo ',às Pinturas do Sr. Graça';
            }
            ?>
        </h1>
        <p>Se procura renovar a sua casa, e dar uma nova vida às paredes, está no lugar certo. Utilizamos apenas materiais de alta qualidade e adaptamo-nos às suas necessidades e orçamento.</p>
        <br><br>
        <button type="button" class="botao-login" onclick="scrollParaProjetos()">Ver projetos anteriores</button>
    </div>
</div>

        <section class="intro-hero"></section>
        <div class="galeria-projetos" id="projetos">
    <h2>Projetos Anteriores</h2>
    <p class="subtitulo-galeria">Veja algumas das nossas transformações mais impressionantes</p>

    <div class="grid-galeria">
        <!-- Projeto 1 -->
        <div class="projeto-galeria">
            <div class="container-imagem">
                <img src="imagens/projetos/projeto1_antes.png" alt="Antes" class="imagem-antes" />
                <img src="imagens/projetos/projeto1_depois.png" alt="Depois" class="imagem-depois" />
                <div class="info-projeto">
                    <h3>Pintura interior</h3>
                    <p>Pintura teto da casa de banho</p>
                </div>
            </div>
            <button class="botao-comparar" onclick="alternarAntesDepois(this)">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="black" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.25 4C10.8358 4 10.5 4.33579 10.5 4.75V6H6C4.34315 6 3 7.34315 3 9V15C3 16.6569 4.34315 18 6 18H10.5V19.25C10.5 19.6642 10.8358 20 11.25 20C11.6642 20 12 19.6642 12 19.25V4.75C12 4.33579 11.6642 4 11.25 4ZM10.5 7.5H6C5.17157 7.5 4.5 8.17157 4.5 9V15C4.5 15.8284 5.17157 16.5 6 16.5H10.5V7.5Z" />
                    <path d="M18 16.5H13.5V18H18C19.6569 18 21 16.6569 21 15V9C21 7.34315 19.6569 6 18 6H13.5V7.5H18C18.8284 7.5 19.5 8.17157 19.5 9V15C19.5 15.8284 18.8284 16.5 18 16.5Z" />
                </svg>
                Alternar Antes/Depois
            </button>
        </div>

        <!-- Projeto 2 -->
        <div class="projeto-galeria">
            <div class="container-imagem">
                <img src="imagens/projetos/projeto2_antes.png" alt="Antes - Pintura Exterior" class="imagem-antes" />
                <img src="imagens/projetos/projeto2_depois.png" alt="Depois - Pintura Exterior" class="imagem-depois" />
                <div class="info-projeto">
                    <h3>Pintura interior</h3>
                    <p>Pintura da parede riscada</p>
                </div>
            </div>
            <button class="botao-comparar" onclick="alternarAntesDepois(this)">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="black" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.25 4C10.8358 4 10.5 4.33579 10.5 4.75V6H6C4.34315 6 3 7.34315 3 9V15C3 16.6569 4.34315 18 6 18H10.5V19.25C10.5 19.6642 10.8358 20 11.25 20C11.6642 20 12 19.6642 12 19.25V4.75C12 4.33579 11.6642 4 11.25 4ZM10.5 7.5H6C5.17157 7.5 4.5 8.17157 4.5 9V15C4.5 15.8284 5.17157 16.5 6 16.5H10.5V7.5Z" />
                    <path d="M18 16.5H13.5V18H18C19.6569 18 21 16.6569 21 15V9C21 7.34315 19.6569 6 18 6H13.5V7.5H18C18.8284 7.5 19.5 8.17157 19.5 9V15C19.5 15.8284 18.8284 16.5 18 16.5Z" />
                </svg>
                Alternar Antes/Depois
            </button>
        </div>

        <!-- Projeto 3 -->
        <div class="projeto-galeria">
            <div class="container-imagem">
                <img src="imagens/projetos/projeto3_antes.png" alt="Antes - Decoração de Quarto" class="imagem-antes" />
                <img src="imagens/projetos/projeto3_depois.png" alt="Depois - Decoração de Quarto" class="imagem-depois" />
                <div class="info-projeto">
                    <h3>Pintura do Quarto</h3>
                    <p>Transformação completa da parede do quarto principal</p>
                </div>
            </div>
            <button class="botao-comparar" onclick="alternarAntesDepois(this)">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="black" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.25 4C10.8358 4 10.5 4.33579 10.5 4.75V6H6C4.34315 6 3 7.34315 3 9V15C3 16.6569 4.34315 18 6 18H10.5V19.25C10.5 19.6642 10.8358 20 11.25 20C11.6642 20 12 19.6642 12 19.25V4.75C12 4.33579 11.6642 4 11.25 4ZM10.5 7.5H6C5.17157 7.5 4.5 8.17157 4.5 9V15C4.5 15.8284 5.17157 16.5 6 16.5H10.5V7.5Z" />
                    <path d="M18 16.5H13.5V18H18C19.6569 18 21 16.6569 21 15V9C21 7.34315 19.6569 6 18 6H13.5V7.5H18C18.8284 7.5 19.5 8.17157 19.5 9V15C19.5 15.8284 18.8284 16.5 18 16.5Z" />
                </svg>
                Alternar Antes/Depois
            </button>
        </div>
    </div>
</div>

<button id="btnTopo" title="Voltar ao topo">↑</button>
<br>
<br>
<br>
<br>
<br>
<br>
<br><button type="button" class="botao-orcamento" onclick="window.location.href='orcamento.php'">Obter um orçamento gratuito</button><br>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Pinturas do Sr. Graça. Todos os direitos reservados.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Efeito de desaparecimento do background
        $(document).ready(function() {
            $(window).scroll(function() {
                var scrollPosition = $(this).scrollTop();
                var windowHeight = $(this).height();
                var documentHeight = $(document).height();
                
                var scrollPercent = scrollPosition / (documentHeight - windowHeight);
                var newOpacity = 0.6 + (scrollPercent * 0.4);
                newOpacity = Math.min(Math.max(newOpacity, 0.6), 1);
                
                $('.overlay').css('background-color', `rgba(255, 255, 255, ${newOpacity})`);
            });

            // Inicializa o carrossel
            setupCarrossel();
        });

        // Menu mobile
        function toggleMenu() {
            const popup = document.getElementById('mobilePopup');
            popup.style.display = popup.style.display === 'block' ? 'none' : 'block';
        }

        // Galeria de projetos
        let estado = "antes";
        let projetos = [
            { nome: "projeto1", elemento: null },
            { nome: "projeto2", elemento: null },
            { nome: "projeto3", elemento: null }
        ];
        let currentIndex = 1; // Índice do projeto central

        function setupCarrossel() {
            const items = document.querySelectorAll('.projeto-item');
            
            // Armazena referências aos elementos
            projetos[0].elemento = items[0];
            projetos[1].elemento = items[1];
            projetos[2].elemento = items[2];
            
            // Adiciona event listeners
            items[0].addEventListener('click', () => rotacionarCarrossel('esquerda'));
            items[1].addEventListener('click', () => rotacionarCarrossel('centro'));
            items[2].addEventListener('click', () => rotacionarCarrossel('direita'));
        }

        function rotacionarCarrossel(direcao) {
            const items = document.querySelectorAll('.projeto-item');
            
            if (direcao === 'esquerda') {
                // Rotaciona para a esquerda (imagem esquerda vai para o centro)
                currentIndex = (currentIndex - 1 + 3) % 3;
                
                // Remove todas as classes
                items.forEach(item => {
                    item.classList.remove('esquerda', 'centro', 'direita');
                });
                
                // Aplica novas classes na ordem correta
                projetos[(currentIndex - 1 + 3) % 3].elemento.classList.add('esquerda');
                projetos[currentIndex].elemento.classList.add('centro');
                projetos[(currentIndex + 1) % 3].elemento.classList.add('direita');
                
                // Reorganiza a ordem no DOM
                const carrossel = document.getElementById('carrossel');
                carrossel.insertBefore(
                    projetos[(currentIndex - 1 + 3) % 3].elemento, 
                    projetos[currentIndex].elemento
                );
            }
            else if (direcao === 'direita') {
                // Rotaciona para a direita (imagem direita vai para o centro)
                currentIndex = (currentIndex + 1) % 3;
                
                // Remove todas as classes
                items.forEach(item => {
                    item.classList.remove('esquerda', 'centro', 'direita');
                });
                
                // Aplica novas classes na ordem correta
                projetos[(currentIndex - 1 + 3) % 3].elemento.classList.add('esquerda');
                projetos[currentIndex].elemento.classList.add('centro');
                projetos[(currentIndex + 1) % 3].elemento.classList.add('direita');
                
                // Reorganiza a ordem no DOM
                const carrossel = document.getElementById('carrossel');
                carrossel.appendChild(projetos[(currentIndex - 1 + 3) % 3].elemento);
            }
            // Se clicar no centro, não faz nada
        }

        let estadoAntes = true;

function alternarAntesDepois(botao) {
    const container = botao.closest('.projeto-galeria');
    const antes = container.querySelector('.imagem-antes');
    const depois = container.querySelector('.imagem-depois');
    
    if (depois.style.opacity === '1') {
        depois.style.opacity = '0';
        antes.style.opacity = '1';
    } else {
        depois.style.opacity = '1';
        antes.style.opacity = '0';
    }
}



        function toggleMenu() {
    const popup = document.getElementById('mobilePopup');
    popup.style.display = (popup.style.display === 'block') ? 'none' : 'block';
}

function scrollParaProjetos() {
    const secaoProjetos = document.getElementById('projetos');
    if (secaoProjetos) {
        secaoProjetos.scrollIntoView({ behavior: 'smooth' });
    }
}

window.onscroll = function() {
    const btn = document.getElementById("btnTopo");
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        btn.style.display = "block";
    } else {
        btn.style.display = "none";
    }
};

// Scroll suave para o topo
document.getElementById("btnTopo").addEventListener("click", function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});
    </script>
</body>
</html>