<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/phpmailer/src/PHPMailer.php';
require __DIR__ . '/phpmailer/src/SMTP.php';
require __DIR__ . '/phpmailer/src/Exception.php';

// Ligação à base de dados
$conn = new mysqli('localhost', 'root', '', 'pinturas');
if ($conn->connect_error) {
    die("Erro na ligação à base de dados: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $conn->real_escape_string($_POST['nome']);
    $telefone = $conn->real_escape_string($_POST['telefone']);
    $email_cliente = $conn->real_escape_string($_POST['email']);
    $tipo_pintura = $conn->real_escape_string($_POST['tipoPintura']);
    $distrito = $conn->real_escape_string($_POST['distrito']);
    $area = (float)$_POST['area'];
    $cor = strtolower($conn->real_escape_string($_POST['cor']));

    // Tabela de preços
    $tabelaPrecos = [
        "interior" => ["#ffffff" => 5, "#f5f5dc" => 5, "default" => 6],
        "exterior" => ["#ffffff" => 6, "#f5f5dc" => 6, "default" => 7.2],
        "ambos" => ["#ffffff" => 10, "#f5f5dc" => 10, "default" => 12]
    ];

    // Fatores por distrito
    $fatoresDistritos = [
        "Lisboa" => 2.0,
        "Porto" => 7.0,
        "Setúbal" => 1.0,
        "Faro" => 4.0,
        "Coimbra" => 4.5,
        "Outros" => 2.0
    ];

    $preco_m2 = $tabelaPrecos[$tipo_pintura][$cor] ?? $tabelaPrecos[$tipo_pintura]['default'];
    $fator_distrito = $fatoresDistritos[$distrito] ?? 1.0;

    $valor_orcamento = $area * $preco_m2 * $fator_distrito;

    // Inserir orçamento na BD
    $stmt = $conn->prepare("INSERT INTO orcamentos (nome, telefone, email, tipo_pintura, distrito, area, cor, valor_orcamento, data_pedido)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("sssssssd", $nome, $telefone, $email_cliente, $tipo_pintura, $distrito, $area, $cor, $valor_orcamento);

    if ($stmt->execute()) {
        $_SESSION['ultimo_orcamento_id'] = $stmt->insert_id;

        // Enviar email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'bagaojoaopedro@gmail.com';
            $mail->Password = 'nyet hoqe aycd tydl'; // substitui se mudares
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('bagaojoaopedro@gmail.com', 'Formulário do Site');
            $mail->addAddress('bagaojoaopedro@gmail.com');

            $mail->isHTML(true);
            $mail->CharSet = 'UTF-8';
            $mail->Subject = 'Pedido de Orçamento';
            $mail->Body = "
    <div style='font-family: Arial, sans-serif; font-size: 14px; color: #333;'>
        <h2 style='color: #c59f25;'>Pedido de Orçamento</h2>
        <p><strong>Nome:</strong> $nome</p>
        <p><strong>Telefone:</strong> $telefone</p>
        <p><strong>Email:</strong> $email_cliente</p>
        <p><strong>Tipo de Pintura:</strong> $tipo_pintura</p>
        <p><strong>Cor:</strong> $cor</p>
        <p><strong>Distrito:</strong> $distrito</p>
        <p><strong>Área (m²):</strong> $area</p>
        <p><strong>Valor Estimado:</strong> " . number_format($valor_orcamento, 2, ',', '.') . "€</p>
    </div>
";


            $mail->send();

            header("Location: sucesso.php");
            exit();
        } catch (Exception $e) {
            echo "Erro ao enviar email: {$mail->ErrorInfo}";
        }
    } else {
        echo "Erro ao guardar orçamento na base de dados: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
