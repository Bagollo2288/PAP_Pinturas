<?php
include('db_connect.php');

// Alterar permissão se solicitado
if (isset($_GET['change_permission'])) {
    $userId = $_GET['change_permission'];

    // Buscar tipo atual do utilizador
    $result = $conn->query("SELECT tipo_utilizador FROM utilizadores WHERE id = $userId");
    if ($result) {
        $user = $result->fetch_assoc();
        $newPermission = ($user['tipo_utilizador'] == 'Admin') ? 'User' : 'Admin';

        // Atualizar o tipo de utilizador
        $update = $conn->query("UPDATE utilizadores SET tipo_utilizador = '$newPermission' WHERE id = $userId");
        if ($update) {
            header("Location: ver_utilizadores.php");
            exit;
        } else {
            echo "Erro ao atualizar permissão: " . $conn->error;
        }
    } else {
        echo "Erro ao obter utilizador: " . $conn->error;
    }
}

// Obter todos os utilizadores
$result = $conn->query("SELECT id, nome_utilizador, telefone, email, tipo_utilizador FROM utilizadores");
if (!$result) {
    die("Erro ao buscar utilizadores: " . $conn->error);
}

$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Lista de Utilizadores</title>
    <link rel="stylesheet" href="styles/ver_utilizadores.css" />
</head>
<body>
    <div class="admin-dashboard">
        <h1>Lista de Utilizadores</h1>

        <!-- Botão Voltar -->
        <button onclick="window.location.href='admin_dashboard.php'" class="btn-voltar">Voltar</button>

        <div class="users-list">
            <table>
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Telefone</th>
                        <th>Tipo de Utilizador</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['nome_utilizador']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['telefone']); ?></td>
                            <td><?php echo htmlspecialchars($user['tipo_utilizador']); ?></td>
                            <td>
                                <a href="ver_utilizadores.php?change_permission=<?php echo $user['id']; ?>">
                                    Alterar Permissão
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
