<?php
session_start();
if (!isset($_SESSION['id']) || $_SESSION['id'] == '') {
    header("Location: login.html"); 
    exit();
}

// Inclui o arquivo de conexão com a base de dados
require_once 'db_connect.php';

// Obtém os dados do utilizador
$userData = ['nome_utilizador' => '', 'email' => '', 'telefone' => '']; // Valores padrão

try {
    $stmt = $conn->prepare("SELECT nome_utilizador, email, telefone FROM utilizadores WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $userData = $result->fetch_assoc();
    }
    
    $stmt->close();
} catch (Exception $e) {
    error_log("Erro ao buscar dados do usuário: " . $e->getMessage());
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="styles/orcamento.css" />
  <title>Pedido de Orçamento</title>
</head>
<body>

<header>
  <div class="navbar">
    <div class="logo">
      <a href="<?php 
          if (isset($_SESSION['id']) && isset($_SESSION['tipo_utilizador'])) {
              echo $_SESSION['tipo_utilizador'] == 1 ? 'admin_dashboard.php' : 'index.php';
          } else {
              echo 'index.php';
          }
      ?>">
        <img src="imagens/Logo.png" alt="Logotipo Pinturas do Sr. Graça" />
      </a>
    </div>
    <ul class="links">
      <li><a href="index.php">Inicio</a></li>
      <li><a href="orcamento.php">Orçamento</a></li>
      <li><a href="simulador.php">Simulador</a></li>
      <li><a href="sobre.php">Sobre Nós</a></li>
      <li><a href="contacto.php">Contacto</a></li>

      <?php if (isset($_SESSION['id']) && $_SESSION['id'] != ''): ?>
          <button type="button" class="botao-logout" onclick="window.location.href='logout.php'">Logout</button>
      <?php else: ?>
          <button type="button" class="botao-login" onclick="window.location.href='login.html'">Login</button>
      <?php endif; ?>
    </ul>
  </div>
</header>

<h1>Pedido de Orçamento</h1>

<form action="enviar_orcamento.php" method="POST">
  <label for="nome">Nome:</label>
  <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($userData['nome_utilizador']); ?>" required>

  <label for="telefone">Telefone:</label>
  <input type="text" id="telefone" name="telefone" value="<?php echo htmlspecialchars($userData['telefone']); ?>" required>

  <label for="email">Email:</label>
  <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($userData['email']); ?>" required>

  <label for="tipoPintura">Tipo de Pintura:</label>
  <select id="tipoPintura" name="tipoPintura" required>
    <option value="">-- Seleciona o tipo --</option>
    <option value="interior">Interior</option>
    <option value="exterior">Exterior</option>
    <option value="ambos">Ambos</option>
  </select>

  <label for="cor">Cor pretendida:</label>
  <input type="color" id="cor" name="cor" value="#ffffff">

  <label for="distrito">Distrito:</label>
  <select id="distrito" name="distrito" required>
    <option value="">-- Seleciona o distrito --</option>
    <option value="Lisboa">Lisboa</option>
    <option value="Porto">Porto</option>
    <option value="Setúbal">Setúbal</option>
    <option value="Faro">Faro</option>
    <option value="Coimbra">Coimbra</option>
    <option value="Outros">Outros</option>
  </select>

  <label for="area">Área (m²):</label>
  <input type="number" id="area" name="area" min="1" placeholder="Insere a área" required>

  <input type="submit" value="Pedir Orçamento">
</form>

<footer>
  <p>&copy; <?php echo date("Y"); ?> Pinturas do Sr. Graça. Todos os direitos reservados.</p>
</footer>

<script>
const areaInput = document.getElementById('area');
const tipoSelect = document.getElementById('tipoPintura');
const corInput = document.getElementById('cor');
const distritoSelect = document.getElementById('distrito');
const estimativaDisplay = document.createElement('p');


const tabelaPrecos = {
  interior: {
    "#ffffff": 5,
    "#f5f5dc": 5,
    "default": 6
  },
  exterior: {
    "#ffffff": 6,
    "#f5f5dc": 6,
    "default": 7.2
  },
  ambos: {
    "#ffffff": 10,
    "#f5f5dc": 10,
    "default": 12
  }
};

// Fatores de preço por distrito
const fatoresDistritos = {
  "Lisboa": 2.0,
  "Porto": 7.0,
  "Setúbal": 1.0,
  "Faro": 4.0,
  "Coimbra": 4.5,
  "Outros": 2.0
};

function calcularFatorDistrito(distrito) {
  if (!distrito || !(distrito in fatoresDistritos)) {
    return 1.0;
  }
  return fatoresDistritos[distrito];
}

function calcularPreco() {
  const area = parseFloat(areaInput.value);
  const tipo = tipoSelect.value;
  const cor = corInput.value.toLowerCase();
  const distrito = distritoSelect.value;

  if (!area || area <= 0 || tipo === "" || !distrito) {
    estimativaDisplay.textContent = "Estimativa: 0,00€";
    return;
  }

  let precoPorMetro = tabelaPrecos[tipo][cor] || tabelaPrecos[tipo]["default"];
  const fatorDistrito = calcularFatorDistrito(distrito);

  const total = area * precoPorMetro * fatorDistrito;
  estimativaDisplay.textContent = `Estimativa: ${total.toFixed(2).replace('.', ',')}€`;
}

areaInput.addEventListener('input', calcularPreco);
tipoSelect.addEventListener('change', calcularPreco);
corInput.addEventListener('input', calcularPreco);
distritoSelect.addEventListener('change', calcularPreco);

window.addEventListener('load', calcularPreco);


</script>

</body>
</html>
