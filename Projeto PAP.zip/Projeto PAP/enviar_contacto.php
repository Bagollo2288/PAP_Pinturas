<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/phpmailer/src/PHPMailer.php';
require __DIR__ . '/phpmailer/src/SMTP.php';
require __DIR__ . '/phpmailer/src/Exception.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $telefone = $_POST['telefone'];
    $email_cliente = $_POST['email'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];

    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'bagaojoaopedro@gmail.com'; // <-- substitui aqui
        $mail->Password = 'nyet hoqe aycd tydl'; // <-- palavra-passe de aplicação
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Informações do remetente e destinatário
        $mail->setFrom('bagaojoaopedro@gmail.com', 'Formulário de Contacto');
        $mail->addAddress('bagaojoaopedro@gmail.com');

        // Conteúdo do email
        $mail->isHTML(true);
        $mail->Subject = 'Mensagem de Contacto: ' . $assunto;
        $mail->Body = "
            <strong>Nome:</strong> $nome<br>
            <strong>Telefone:</strong> $telefone<br>
            <strong>Email:</strong> $email_cliente<br>
            <strong>Assunto:</strong> $assunto<br>
            <strong>Mensagem:</strong><br>$mensagem
        ";

        $mail->send();
        header("Location: sucesso.php"); // Redireciona para página de sucesso
        exit();
    } catch (Exception $e) {
        echo "Erro ao enviar: {$mail->ErrorInfo}";
    }
}
?>
