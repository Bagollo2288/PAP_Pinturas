<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="styles/sobre.css"> <!-- ou cria um sobre.css se quiseres estilos diferentes -->
  <title>Sobre Nós - Pinturas do Sr. Graça</title>
</head>
<body>
  <header>
    <div class="navbar">
            <div class="logo"><a href="#"><img src="imagens/Logo.png" alt="Logotipo Pinturas do Sr. Graça" /></a></div>
            <ul class="links">
                <li><a href="index.php">Inicio</a></li>
                <li><a href="orcamento.php">Orçamento</a></li>
                <li><a href="simulador.php">Simulador</a></li>
                <li><a href="sobre.php">Sobre Nós</a></li>
                <li><a href="contacto.php">Contacto</a></li>

                <!-- Verifica se o utilizador está logado -->
                <?php if (isset($_SESSION['id']) && $_SESSION['id'] != ''): ?>
                    <button type="button" class="botao-logout" onclick="window.location.href='logout.php'">Logout</button> <!-- Se o utilizador estiver logado, mostra o botão de Logout -->
                <?php else: ?>
                    <button type="button" class="botao-login" onclick="window.location.href='login.html'">Login</button> <!-- Se o utilizador não estiver logado, mostra o botão de Login -->
                <?php endif; ?>
            </ul>
            
        </div>
  </header>

  <main class="sobre-nos">
    <section class="intro">
      <h1>Sobre Nós</h1>
      <p>Bem-vindo à <strong>Pinturas do Sr. Graça</strong>, uma empresa especializada em dar nova vida às suas paredes!</p>
    </section>

    <section class="historia">
      <h2>A nossa história</h2>
      <p>Fundada em 2024, a Pinturas do Sr. Graça nasceu da paixão por transformar espaços com cor e qualidade. Ao longo dos anos, temos vindo a crescer e a inovar, sempre com o objetivo de satisfazer os nossos clientes.</p>
    </section>

    <section class="valores">
      <h2>Os nossos valores</h2>
      <ul>
        <li><strong>Profissionalismo</strong>: Cada projeto é tratado com dedicação e seriedade.</li>
        <li><strong>Qualidade</strong>: Trabalhamos apenas com os melhores materiais e técnicas.</li>
        <li><strong>Confiança</strong>: Construímos relações duradouras com os nossos clientes.</li>
      </ul>
    </section>

    <section class="equipa">
      <h2>A nossa equipa</h2>
      <p>Contamos com uma equipa de profissionais experientes, que estão sempre prontos a oferecer aconselhamento personalizado e soluções criativas para qualquer espaço.</p>
    </section>
  </main>

  <footer>
    <p>&copy; <?php echo date("Y"); ?> Pinturas do Sr. Graça. Todos os direitos reservados.</p>
  </footer>
</body>
</html>
