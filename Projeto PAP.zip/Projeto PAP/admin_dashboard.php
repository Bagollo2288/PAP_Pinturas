<?php
session_start();
if (!isset($_SESSION['id']) || $_SESSION['id'] == '') {
    header("Location: login.html"); 
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de Administração</title>
    <link rel="stylesheet" href="styles/admin_dashboard.css">
</head>
<body>
    <header>
            <div class="navbar">
                <div class="logo"><a href="#"><img src="imagens/Logo.png" alt="Logotipo Pinturas do Sr. Graça" /></a></div>
                <ul class="links">
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="orcamento.php">Orçamento</a></li>
                    <li><a href="simulador.php">Simulador</a></li>
                    <li><a href="sobre.php">Sobre Nós</a></li>
                    <li><a href="contacto.php">Contacto</a></li>

                    <li>
<?php if (isset($_SESSION['id']) && $_SESSION['id'] != ''): ?>
    <button type="button" class="botao-logout" onclick="window.location.href='logout.php'">Logout</button>
<?php else: ?>
    <button type="button" class="botao-login" onclick="window.location.href='login.html'">Login</button>
<?php endif; ?>
</li>

                </ul>
                <button class="menu-toggle" onclick="toggleMenu()">☰</button>

        <!-- Continua dentro da navbar -->
        <div class="mobile-popup" id="mobilePopup">
            <button class="close-btn" onclick="toggleMenu()">✕</button>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="orcamento.php">Orçamento</a></li>
                <li><a href="simulador.php">Simulador</a></li>
                <li><a href="sobre.php">Sobre Nós</a></li>
                <li><a href="contacto.php">Contacto</a></li>
                <?php if (isset($_SESSION['id']) && $_SESSION['id'] != ''): ?>
                    <button class="botao-logout" onclick="window.location.href='logout.php'">Logout</button>
                <?php else: ?>
                    <button class="botao-login" onclick="window.location.href='login.html'">Login</button>
                <?php endif; ?>
            </ul>
        </div>
    </div>
        </header>
    <div class="admin-dashboard">
        <h1>Painel de Administração</h1>

        <div class="menu-admin">
            <a href="ver_utilizadores.php" class="botao-admin">Utilizadores</a>
            <a href="ver_orcamentos.php" class="botao-admin">Orçamento</a>
        </div>
    </div>
</body>
</html>
