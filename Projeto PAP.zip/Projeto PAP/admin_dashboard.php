<?php
session_start();
if (!isset($_SESSION['id']) || $_SESSION['id'] == '') {
    header("Location: login.html"); 
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de Administração</title>
    <link rel="stylesheet" href="styles/admin_dashboard.css">
</head>
<body>
    <div class="admin-dashboard">
        <h1>Painel de Administração</h1>

        <div class="menu-admin">
            <a href="ver_utilizadores.php" class="botao-admin">Utilizadores</a>
            <a href="ver_orcamentos.php" class="botao-admin">Orçamento</a>
        </div>

        <button onclick="window.location.href='logout.php'" class="botao-logout">Logout</button>
    </div>
</body>
</html>
