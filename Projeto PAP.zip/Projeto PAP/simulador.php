<!-- apenas pessoas com o   login feito podem entrar -->
<?php
session_start();
if (!isset($_SESSION['id']) || $_SESSION['id'] == '') {
    header("Location: login.html"); // Redireciona para login se não estiver autenticado
    exit();
}
?>
<!-- ---------------------------------------------------->
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="styles/simulador.css">

  <!-- liga se á biblioteca three.js, que permite criar graficos 3d-->
  <script src="https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js"></script>
  <!-- --------------------------------------------------------------->
</head>
<body>
  <header>
    <div class="navbar">
            <div class="logo">
    <a href="<?php 
        if (isset($_SESSION['id']) && isset($_SESSION['tipo_utilizador'])) {
            echo $_SESSION['tipo_utilizador'] == 1 ? 'admin_dashboard.php' : 'index.php';
        } else {
            echo 'index.php';
        }
    ?>">
        <img src="imagens/Logo.png" alt="Logotipo Pinturas do Sr. Graça" />
    </a>
</div>
            <ul class="links">
                <li><a href="index.php">Inicio</a></li>
                <li><a href="orcamento.php">Orçamento</a></li>
                <li><a href="simulador.php">Simulador</a></li>
                <li><a href="sobre.php">Sobre Nós</a></li>
                <li><a href="contacto.php">Contacto</a></li>

                <!-- Verifica se o utilizador está logado -->
                <?php if (isset($_SESSION['id']) && $_SESSION['id'] != ''): ?>
                    <button type="button" class="botao-logout" onclick="window.location.href='logout.php'">Logout</button> <!-- Se o utilizador estiver logado, mostra o botão de Logout -->
                <?php else: ?>
                    <button type="button" class="botao-login" onclick="window.location.href='login.html'">Login</button> <!-- Se o utilizador não estiver logado, mostra o botão de Login -->
                <?php endif; ?>
            </ul>
            
        </div>
  </header>
  <div class="layout">

  <!-- aqui sao os controlos, escolher a cor, qual parede e o chão -->
    <div class="controls">
      <label>Escolhe uma cor:</label>
      <input type="color" id="colorPicker" value="#ff0000">
      <label for="wallSelector">Escolhe a parede:</label>
      <select id="wallSelector">
        <option value="frente">Frente</option>
        <option value="esquerda">Esquerda</option>
        <option value="direita">Direita</option>
      </select>
      <label for="floorSelector">Escolhe o tipo de chão:</label>
      <select id="floorSelector">
        <option value="___" hidden selected></option>
        <option value="marmore">Mármore</option>
        <option value="madeira-cinza">Madeira Cinza</option>
        <option value="flutuante-castanho-claro">Flutuante castanho claro</option>
        <option value="flutuante-castanho-escuro">Flutuante castanho escuro</option>
        <option value="ceramica">Ceramica</option>
      </select>
    </div>
    <!-- --------------------------------------------------------------->
    
    <div id="scene-container"></div>
</div>
  <script>

    window.addEventListener('pageshow', function(event) {
    // Se for um "back/forward" (persistido no histórico)
    if (event.persisted) {
        fetch('logout.php')
            .then(() => {
                // Opcionalmente força refresh para garantir estado limpo
                window.location.reload();
            });
    }
});
    // cria a cena em 3d, a camera e o renderizador que é o que mostra tudo no ecrã
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xffffff);

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 2, 7);
    camera.lookAt(0, 1, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.getElementById('scene-container').appendChild(renderer.domElement);

    // ----------------------------------------------------------------------------------

    // Função para criar uma parede ou chão com contorno preto
    function criarParede(largura, altura, corHex) {
      const geometria = new THREE.PlaneGeometry(largura, altura);
      const material = new THREE.MeshBasicMaterial({ color: corHex, side: THREE.DoubleSide });
      const plano = new THREE.Mesh(geometria, material);

      const contornoGeo = new THREE.EdgesGeometry(geometria);
      const contornoMat = new THREE.LineBasicMaterial({ color: 0x000000 });
      const contorno = new THREE.LineSegments(contornoGeo, contornoMat);
      plano.add(contorno);

      return plano;
    }
    //------------------------------------------------------------------------------------------

    // medidas das paredes e do chão
    const largura = 6;
    const altura = 3;
    const profundidade = 5;
    const ajusteAltura = 0.01;
    // -----------------------------------

    // cria a parede da frente
    const paredeFrente = criarParede(largura, altura, 0xffffff);
    paredeFrente.position.set(0, altura / 2 + ajusteAltura, -profundidade / 2);
    scene.add(paredeFrente);
    // -----------------------------------

    // cria a parede da esquerda
    const paredeEsquerda = criarParede(profundidade, altura, 0xffffff);
    paredeEsquerda.rotation.y = Math.PI / 2;
    paredeEsquerda.position.set(-largura / 2, altura / 2 + ajusteAltura, 0);
    scene.add(paredeEsquerda);
    // -----------------------------------

    // cria a parede da direita
    const paredeDireita = criarParede(profundidade, altura, 0xffffff);
    paredeDireita.rotation.y = -Math.PI / 2;
    paredeDireita.position.set(largura / 2, altura / 2 + ajusteAltura, 0);
    scene.add(paredeDireita);
    // -----------------------------------

    // cria o chão
    const chao = criarParede(largura, profundidade, 0xffffff);
    chao.rotation.x = -Math.PI / 2;
    chao.position.set(0, 0, 0);
    scene.add(chao);
    // -----------------------------------

    // muda o tipo de textura do chão
    function mudarTexturaChao(tipo) {
      let textura;
      if (tipo === 'marmore') {
        textura = new THREE.TextureLoader().load('imagens/marmore.png'); // Substituir pelo caminho real da imagem
      } else if (tipo === 'madeira-cinza') {
        textura = new THREE.TextureLoader().load('imagens/madeira-cinza.png'); // Substituir pelo caminho real da imagem
      } else if (tipo === 'flutuante-castanho-claro') {
        textura = new THREE.TextureLoader().load('imagens/chao-flutuante-castanho-claro.png'); // Substituir pelo caminho real da imagem
      } else if (tipo === 'flutuante-castanho-escuro') {
        textura = new THREE.TextureLoader().load('imagens/chao-flutuante-castanho-escuro.png'); // Substituir pelo caminho real da imagem
      } else if (tipo === 'ceramica') {
        textura = new THREE.TextureLoader().load('imagens/ceramica.png'); // Substituir pelo caminho real da imagem
      }

      chao.material = new THREE.MeshBasicMaterial({ map: textura });
    }
    // ------------------------------------------------------------

    // pinta as paredes conforme a cor que o cliente seleciona
    document.getElementById('colorPicker').addEventListener('input', (e) => {
      const cor = new THREE.Color(e.target.value);
      const paredeSelecionada = document.getElementById('wallSelector').value;

      if (paredeSelecionada === 'frente') {
        paredeFrente.material.color = cor;
      } else if (paredeSelecionada === 'esquerda') {
        paredeEsquerda.material.color = cor;
      } else if (paredeSelecionada === 'direita') {
        paredeDireita.material.color = cor;
      }
    });
    // -------------------------------------------------------------

    // altera o chao conforme o cliente seleciona
    document.getElementById('floorSelector').addEventListener('change', (e) => {
      const tipoChao = e.target.value;
      mudarTexturaChao(tipoChao);
    });
    // ----------------------------------------------------------------

    // faz com que conforme o utiliador mude a cor, no modelo 3d mude ao vivo
    function animar() {
      requestAnimationFrame(animar);
      renderer.render(scene, camera);
    }
    animar();
    // -------------------------------------------------------------------
  </script>

  <footer>
    <p>&copy; <?php echo date("Y"); ?> Pinturas do Sr. Graça. Todos os direitos reservados.</p>
  </footer>
</body>
</html>
