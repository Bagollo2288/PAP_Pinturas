CREATE DATABASE  IF NOT EXISTS `pinturas` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `pinturas`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: pinturas
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orcamentos`
--

DROP TABLE IF EXISTS `orcamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orcamentos` (
  `id` int(11) NOT NULL,
  `id_utilizador` int(11) DEFAULT NULL,
  `nome` varchar(100) NOT NULL,
  `telefone` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `data_pedido` datetime NOT NULL,
  `data_envio` datetime DEFAULT current_timestamp(),
  `tipo_pintura` varchar(50) NOT NULL,
  `distrito` varchar(100) DEFAULT NULL,
  `area` int(11) NOT NULL,
  `valor_orcamento` decimal(10,2) DEFAULT NULL,
  `cor` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `orcamentos` (`id`, `id_utilizador`, `nome`, `telefone`, `email`, `data_pedido`, `data_envio`, `tipo_pintura`, `distrito`, `area`, `valor_orcamento`, `cor`) VALUES
(1, NULL, 'joao', '12345', '1@1.1', '2025-06-13 10:45:25', '2025-06-13 10:45:25', 'interior', 'Setúbal', 100, 600.00, '#dac8c8'),
(2, NULL, 'joao', '12345', '1@1.1', '2025-06-13 10:45:44', '2025-06-13 10:45:44', 'ambos', 'Porto', 100, 8400.00, '#ff0000'),
(3, NULL, 'admin', '123456789', 'admin@gmail.com', '2025-06-13 10:59:32', '2025-06-13 10:59:32', 'ambos', 'Lisboa', 465746, 11177904.00, '#3e2323');



--
-- Table structure for table `utilizadores`
--

DROP TABLE IF EXISTS `utilizadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilizadores` (
  `id` int(11) NOT NULL,
  `nome_utilizador` varchar(255) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tipo_utilizador` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `utilizadores`
--

INSERT INTO `utilizadores` (`id`, `nome_utilizador`, `telefone`, `email`, `password`, `tipo_utilizador`, `created_at`) VALUES
(1, 'admin', '123456789', 'admin@gmail.com', '$2y$10$Ixx.ZLNehe1eskeS4FwrxuhKZx4GlvDvYXg7fcs0U3YYPUvJ7GhMW', 1, '2025-05-05 11:37:55'),
(2, 'joao', '12345', '1@1.1', '$2y$10$ps3hD.ZrY.wcqSILuViIs.oIq2e7.lGe9syVoOxGEe.d8.OJl.lrS', 0, '2025-05-05 12:38:43');



ALTER TABLE `orcamentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_orcamentos_utilizadores` (`id_utilizador`);

--
-- Índices para tabela `utilizadores`
--
ALTER TABLE `utilizadores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `orcamentos`
--
ALTER TABLE `orcamentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `utilizadores`
--
ALTER TABLE `utilizadores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `orcamentos`
--
ALTER TABLE `orcamentos`
  ADD CONSTRAINT `fk_orcamentos_utilizadores` FOREIGN KEY (`id_utilizador`) REFERENCES `utilizadores` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

--
-- Dumping events for database 'pinturas'
--

--
-- Dumping routines for database 'pinturas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-27 15:24:42
