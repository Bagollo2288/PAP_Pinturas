<?php
include('db_connect.php');

header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=orcamentos_lucros_por_mes.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Configurações custos
$custo_por_km = 0.5;
$distancias = [
    'Lisboa' => 20,
    'Porto' => 300,
    'Coimbra' => 150,
    'Setúbal' => 40,
    'Faro' => 280,
    // adicionar mais distritos conforme necessário
];
$preco_tinta_por_m2 = 2.5;
$custo_materiais = 30;

$result = $conn->query("SELECT id, nome, telefone, email, tipo_pintura, cor, distrito, area, valor_orcamento, data_envio, data_pedido FROM orcamentos ORDER BY data_envio DESC");

if (!$result) {
    die("Erro ao buscar orçamentos: " . $conn->error);
}

echo '<html><head><meta charset="UTF-8"></head><body>';

// Tabela detalhada
echo '<h2>Detalhes dos Orçamentos</h2>';
echo '<table border="1" style="border-collapse: collapse;">';
echo '<tr style="background-color: #c59f25; color: white; font-weight: bold;">';
echo '<th>ID</th><th>Nome</th><th>Telefone</th><th>Email</th><th>Tipo de Pintura</th><th>Cor</th><th>Distrito</th><th>Área (m²)</th><th>Valor Orçamento (€)</th><th>Dinheiro Gasto (€)</th><th>Lucro (€)</th><th>Data de Envio</th><th>Data do Pedido</th>';
echo '</tr>';

// Array para acumular lucro por mês
$lucro_por_mes = [];

while ($row = $result->fetch_assoc()) {
    $distancia = isset($distancias[$row['distrito']]) ? $distancias[$row['distrito']] : 50;
    $custo_viagem = $distancia * $custo_por_km;
    $custo_tinta = $row['area'] * $preco_tinta_por_m2;
    $dinheiro_gasto = $custo_viagem + $custo_tinta + $custo_materiais;
    $lucro = $row['valor_orcamento'] - $dinheiro_gasto;

    // Extrair ano-mês da data_envio para agrupamento
    $data_envio = new DateTime($row['data_envio']);
    $ano_mes = $data_envio->format('Y-m'); // ex: "2025-06"

    if (!isset($lucro_por_mes[$ano_mes])) {
        $lucro_por_mes[$ano_mes] = 0;
    }
    $lucro_por_mes[$ano_mes] += $lucro;

    echo '<tr>';
    echo '<td>' . $row['id'] . '</td>';
    echo '<td>' . htmlspecialchars($row['nome']) . '</td>';
    echo '<td>' . htmlspecialchars($row['telefone']) . '</td>';
    echo '<td>' . htmlspecialchars($row['email']) . '</td>';
    echo '<td>' . htmlspecialchars($row['tipo_pintura']) . '</td>';
    echo '<td style="background-color:' . htmlspecialchars($row['cor']) . ';">' . htmlspecialchars($row['cor']) . '</td>';
    echo '<td>' . htmlspecialchars($row['distrito']) . '</td>';
    echo '<td>' . htmlspecialchars($row['area']) . '</td>';
    echo '<td>' . number_format($row['valor_orcamento'], 2, ',', '.') . '</td>';
    echo '<td>' . number_format($dinheiro_gasto, 2, ',', '.') . '</td>';
    echo '<td>' . number_format($lucro, 2, ',', '.') . '</td>';
    echo '<td>' . htmlspecialchars($row['data_envio']) . '</td>';
    echo '<td>' . htmlspecialchars($row['data_pedido']) . '</td>';
    echo '</tr>';
}

echo '</table>';

// Tabela resumo por mês
echo '<h2>Resumo de Lucros por Mês</h2>';
echo '<table border="1" style="border-collapse: collapse; width: 300px;">';
echo '<tr style="background-color: #c59f25; color: white; font-weight: bold;">';
echo '<th>Mês</th><th>Lucro Total (€)</th>';
echo '</tr>';

// Ordenar por data crescente (opcional)
ksort($lucro_por_mes);

foreach ($lucro_por_mes as $mes => $lucro_total) {
    // Formatando mês para "MM/YYYY"
    $dateObj = DateTime::createFromFormat('Y-m', $mes);
    $mes_formatado = $dateObj->format('m/Y');
    echo '<tr>';
    echo '<td style="text-align:center;">' . $mes_formatado . '</td>';
    echo '<td style="text-align:right;">' . number_format($lucro_total, 2, ',', '.') . '</td>';
    echo '</tr>';
}

echo '</table>';

echo '</body></html>';
exit;
?>
