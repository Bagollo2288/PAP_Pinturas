<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/phpmailer/src/PHPMailer.php';
require __DIR__ . '/phpmailer/src/SMTP.php';
require __DIR__ . '/phpmailer/src/Exception.php';

// Ligação à base de dados (altera com os teus dados)
$conn = new mysqli('localhost', 'root', '', 'pinturas');

if ($conn->connect_error) {
    die("Erro na ligação à base de dados: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $conn->real_escape_string($_POST['nome']);
    $telefone = $conn->real_escape_string($_POST['telefone']);
    $email_cliente = $conn->real_escape_string($_POST['email']);
    $mensagem = $conn->real_escape_string($_POST['mensagem']);

    // Inserir na base de dados
    $sql = "INSERT INTO orcamentos (nome, telefone, email, mensagem, data_pedido) VALUES ('$nome', '$telefone', '$email_cliente', '$mensagem', NOW())";

    if ($conn->query($sql) === TRUE) {
        // Agora enviar o email
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'bagaojoaopedro@gmail.com'; // <-- substitui aqui
            $mail->Password = 'nyet hoqe aycd tydl';       // <-- substitui aqui
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('bagaojoaopedro@gmail.com', 'Formulário do Site');
            $mail->addAddress('bagaojoaopedro@gmail.com');

            $mail->isHTML(true);
            $mail->Subject = 'Pedido de Orçamento';
            $mail->Body = "
                <strong>Nome:</strong> $nome<br>
                <strong>Telefone:</strong> $telefone<br>
                <strong>Email:</strong> $email_cliente<br>
                <strong>Mensagem:</strong><br>$mensagem
            ";

            $mail->send();
            header("Location: sucesso.php");
            exit();
        } catch (Exception $e) {
            echo "Erro ao enviar email: {$mail->ErrorInfo}";
        }
    } else {
        echo "Erro ao guardar orçamento na base de dados: " . $conn->error;
    }

    $conn->close();
}
?>
