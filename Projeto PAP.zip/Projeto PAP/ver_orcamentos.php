<?php
include('db_connect.php');

// Obter todos os orçamentos
$result = $conn->query("SELECT id, nome, telefone, email, mensagem, data_envio FROM orcamentos ORDER BY data_envio DESC");
if (!$result) {
    die("Erro ao buscar orçamentos: " . $conn->error);
}

$orcamentos = [];
while ($row = $result->fetch_assoc()) {
    $orcamentos[] = $row;
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Lista de Orçamentos</title>
    <link rel="stylesheet" href="styles/ver_utilizadores.css" />
</head>
<body>
    <div class="admin-dashboard">
        <h1>Lista de Orçamentos</h1>

        <!-- Botão Voltar -->
        <button onclick="window.location.href='admin_dashboard.php'" class="btn-voltar">Voltar</button>

        <div class="users-list">
            <table>
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Telefone</th>
                        <th>Email</th>
                        <th>Mensagem</th>
                        <th>Data de Envio</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orcamentos as $orcamento): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($orcamento['nome']); ?></td>
                            <td><?php echo htmlspecialchars($orcamento['telefone']); ?></td>
                            <td><?php echo htmlspecialchars($orcamento['email']); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($orcamento['mensagem'])); ?></td>
                            <td><?php echo htmlspecialchars($orcamento['data_envio']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
