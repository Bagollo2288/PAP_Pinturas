<?php
include('db_connect.php');

// Obter todos os orçamentos incluindo cor e valor_orcamento
$result = $conn->query("SELECT id, nome, telefone, email, tipo_pintura, cor, distrito, area, valor_orcamento, data_envio, data_pedido FROM orcamentos ORDER BY data_envio DESC");

if (!$result) {
    die("Erro ao buscar orçamentos: " . $conn->error);
}

$orcamentos = [];
while ($row = $result->fetch_assoc()) {
    $orcamentos[] = $row;
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Lista de Orçamentos</title>
    <link rel="stylesheet" href="styles/ver_utilizadores.css" />
</head>
<body>
    <div class="admin-dashboard">
        <h1>Lista de Orçamentos</h1>

        <!-- Botão Voltar -->
        <button onclick="window.location.href='admin_dashboard.php'" class="btn-voltar">Voltar</button>

        <div class="users-list">
            <table>
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Telefone</th>
                        <th>Email</th>
                        <th>Tipo de Pintura</th>
                        <th>Cor</th>
                        <th>Distrito</th>
                        <th>Área (m²)</th>
                        <th>Estimativa Valor (€)</th>
                        <th>Data de Envio</th>
                        <th>Data do Pedido</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($orcamentos as $orcamento): ?>
                        <tr>
                            <td><?= htmlspecialchars($orcamento['nome']); ?></td>
                            <td><?= htmlspecialchars($orcamento['telefone']); ?></td>
                            <td><?= htmlspecialchars($orcamento['email']); ?></td>
                            <td><?= htmlspecialchars($orcamento['tipo_pintura']); ?></td>
                            <td>
  <?= htmlspecialchars($orcamento['cor']); ?>
  <span style="display:inline-block; width:20px; height:20px; background-color: <?= htmlspecialchars($orcamento['cor']); ?>; border:1px solid #000; margin-left:5px; vertical-align: middle;"></span>
</td>

                            <td><?= htmlspecialchars($orcamento['distrito']); ?></td>
                            <td><?= htmlspecialchars($orcamento['area']); ?></td>
                            <td><?= number_format($orcamento['valor_orcamento'], 2, ',', '.'); ?></td>
                            <td><?= htmlspecialchars($orcamento['data_envio']); ?></td>
                            <td><?= htmlspecialchars($orcamento['data_pedido']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>

            </table>

           <br> <button class="btn-voltar" onclick="window.location.href='exportar_lucros.php'">Exportar Lucros</button>

        </div>
    </div>
</body>
</html>
